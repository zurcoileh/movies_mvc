
import org.json.JSONException;

public class Test {

	public static void main(String[] args) throws JSONException {
		// TODO Auto-generated method stub
		
	/*	Interface webmovies = new Interface();
		
		//Adicona novos filmes a interface
		webmovies.addMovie(new Movie(103,180, "Interstellar", 2014, null,new Espec(Gender.Fiction, "Warnner")));
		webmovies.addMovie(new Movie(105,180, "Night at the Museum", 2015, null,new Espec(Gender.Adventure, "Warnner")));
		webmovies.addMovie(new Movie(107,150, "300", 2013, null,new Espec(Gender.Action, "Universal")));
		webmovies.addMovie(new Movie(109,150, "Iroman", 2012, null,new Espec(Gender.Action, "Marvel")));
		webmovies.addMovie(new Movie(111,180, "Birdman", 2015, null,new Espec(Gender.Drama, "Warnner")));
		webmovies.addMovie(new Movie(113,180, "American Sniper", 2015, null,new Espec(Gender.Action, "MGM")));
		webmovies.addMovie(new Movie(115,150, "12 years a slave", 2012, null,new Espec(Gender.Drama, "Paramount")));
		webmovies.addMovie(new Movie(118,150, "Tha fault in our stars", 2013, null,new Espec(Gender.Romance, "MGM")));
		//ObjectSet result = web.searchMovie(new Espec(Gender.Fiction, "Warnner"));			
		
		
	    //Imprime a lista de filmes armazenados
		System.out.println(webmovies);
		
		System.out.println("*************************************************************************************");
		
		//Adiciona nota pra os filmes		
		webmovies.addGrade(105, 80);
		webmovies.addGrade(107, 90);
		webmovies.addGrade(108, 75);
		
		//teste busca pelo ID
		ObjectSet<Movie> result = webmovies.searchId(103);		
		
		if (!result.isEmpty())
			for (Movie mv : result)
				System.out.println(mv);
		else
			System.out.println("id n�o encontrado");
		
		System.out.println("*************************************************************************************");
		
		//teste de busca pela espec
		ObjectSet res = webmovies.searchMovie(new Espec(Gender.Action, "MGM"));	
		
		if (!res.isEmpty())
			for (Object mv : res)
				System.out.println(mv);
		else
			System.out.println("especifica��o n�o encontrada");
			
		System.out.println("*************************************************************************************");
		
		//teste de busca por palavra chave
		res = webmovies.searchKeyword("Marvel");	
			
		if (!res.isEmpty())
			for (Object mv : res)
				System.out.println(mv);
		else
			System.out.println("n�o encontrado!");
		
		System.out.println("*************************************************************************************");
		
		//deleta filme pelo id
		webmovies.delMovie(111);
		System.out.println(webmovies);
		
		
		
	/*	webmovies.addGrade(115, 95);
		
		ObjectSet test = webmovies.searchId(115);			
		Movie found = (Movie) test.next();			
			System.out.println(found.getRating());
			System.out.println(found.getGrade());
			System.out.println(found.getQtVotes());		*/		
			
		
	
	
	}
}
